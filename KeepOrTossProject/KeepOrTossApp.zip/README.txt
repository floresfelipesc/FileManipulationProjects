DESCRIPTION:
This is a Winforms App that given a folder's filepath, will display each file
sequentially and gives you the choice of keeping or deleting the file. 

HOW TO INSTALL: 
1. Navigate into the "Executable" Folder
2. Click the green "Code" button
3. Download ZIP
4. Navigate to the Zip file on your system
5. Extract Zip
6. Run the .exe file

HOW TO USE: 
1. Run the .exe file
2. Provide the filepath for a folder on your computer
3. The program will now display each image files in the filepath sequentially
and create a folder within the filepath named "ToToss"
4. Select the Keep or Toss buttons to either keep the image, or move the image to 
the "ToToss" folder
5. An alert will be displayed when you finish going through each image
6. Navigate to the filepath where the "ToToss" folder and delete the folder
7. You are now finished! 